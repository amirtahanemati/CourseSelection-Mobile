import React from "react";
import { TouchableOpacity, View } from "react-native";
import { Course, useCourseStore } from "../../store/useCourseStore"; // 👈 مطمئن شو کلمه export قبل از تایپ Course در این فایل نوشته شده باشد
import Text from "../ui/CustomText"; // 👈 استفاده از کاستوم تکست برای اعمال فونت

interface Props {
  course: Course;
  isAdded: boolean;
  onToggle: () => void;
}

export default function CourseCard({ course, isAdded, onToggle }: Props) {
  // دریافت وضعیت تم
  const theme = useCourseStore((state) => state.theme);
  const isDark = theme === "dark";

  return (
    <View
      className={`p-4 mb-3 rounded-2xl shadow-sm border ${
        isDark ? "bg-[#12141c] border-[#1f222a]" : "bg-white border-gray-200"
      }`}
    >
      {/* راست‌چین کردن متون */}
      <Text
        className={`text-base font-extrabold text-right ${
          isDark ? "text-white" : "text-gray-900"
        }`}
      >
        {course.name} {/* 👈 پراپرتی صحیح name است نه title */}
      </Text>

      <Text
        className={`text-xs mt-1 text-right font-medium ${
          isDark ? "text-gray-400" : "text-gray-500"
        }`}
      >
        استاد: {course.professor || "-"}
      </Text>

      {/* استفاده از flex-row-reverse برای چیدمان RTL دکمه و واحدها */}
      <View className="flex-row-reverse justify-between items-center mt-5">
        <View
          className={`px-2.5 py-1 rounded-md border ${
            isDark
              ? "bg-[#172033] border-[#1e3a8a]"
              : "bg-blue-50 border-blue-200"
          }`}
        >
          <Text className="text-xs font-bold text-blue-500">
            {course.units} واحد {/* 👈 پراپرتی صحیح units است نه credits */}
          </Text>
        </View>

        <TouchableOpacity
          onPress={onToggle}
          activeOpacity={0.8}
          className={`px-5 py-2 rounded-xl items-center justify-center shadow-sm ${
            isAdded ? "bg-red-500" : "bg-blue-500"
          }`}
        >
          <Text className="text-white font-extrabold text-sm">
            {isAdded ? "حذف" : "اخذ درس"}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
